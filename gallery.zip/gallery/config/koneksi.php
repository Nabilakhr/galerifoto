<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'galeri_foto';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);

?>